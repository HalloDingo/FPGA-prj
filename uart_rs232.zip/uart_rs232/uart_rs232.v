module uart_rs232
(
input		wire			sys_clk,
input 	wire			sys_rst_n,
input 	wire			rx,
output	wire			tx
);

wire		[7:0]			rx_data;
wire						rx_done;
wire						tx_start;
wire		[7:0]			tx_data;
wire						tx_busy;									

uart_rx	
#(	.BAUD				('d115200),//'d115200
	.CLK_FREQ		('d50_000_000)//'d50_000_000
)
inst_rx
(
.sys_clk(sys_clk),
.sys_rst_n(sys_rst_n),
.rx(rx),
.rx_data(rx_data),		   
.rx_done(rx_done)
);

uart_tx
#( .BAUD				('d115200),//'d115200
	.CLK_FREQ		('d50_000_000)//'d50_000_000
)
inst_tx
(
.sys_clk(sys_clk),
.sys_rst_n(sys_rst_n),
.tx_start(tx_start),
.tx_data(tx_data),	
.tx_busy(tx_busy),
.tx(tx)
);

uart_data_loop inst_uart_data_loop
(
.sys_clk(sys_clk),
.sys_rst_n(sys_rst_n),
.rx_data(rx_data),	
.rx_done(rx_done),
.tx_busy(tx_busy),
.tx_start(tx_start),
.tx_data(tx_data)
);
endmodule