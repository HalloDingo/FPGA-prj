transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+D:/FPGAprj/uart_rs232/rtl {D:/FPGAprj/uart_rs232/rtl/uart_rx.v}
vlog -vlog01compat -work work +incdir+D:/FPGAprj/uart_rs232 {D:/FPGAprj/uart_rs232/uart_rs232.v}
vlog -vlog01compat -work work +incdir+D:/FPGAprj/uart_rs232/rtl {D:/FPGAprj/uart_rs232/rtl/uart_tx.v}
vlog -vlog01compat -work work +incdir+D:/FPGAprj/uart_rs232/rtl {D:/FPGAprj/uart_rs232/rtl/uart_data_loop.v}

vlog -vlog01compat -work work +incdir+D:/FPGAprj/uart_rs232/simulation/modelsim {D:/FPGAprj/uart_rs232/simulation/modelsim/tb_uart.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  tb_uart

add wave *
view structure
view signals
run 200 us
