`timescale 1ns/1ns
module tb_uart();
reg 			sys_clk;
reg 			sys_rst_n;
reg			rx;
wire			tx;
initial begin
			sys_clk=0;
			sys_rst_n=0;
			rx=1;
			#50	sys_rst_n=1;
			#50	rx=0;
			#8680	rx=1;
			#8680	rx=0;
			#8680	rx=1;
			#8680	rx=1;
			#8680	rx=0;
			#8680	rx=1;
			#8680	rx=1;
			#8680	rx=0;
			#8680	rx=1;
			
end


always #10 sys_clk=~sys_clk;

uart_rs232 inst_uart_rs232
(
.sys_clk(sys_clk),
.sys_rst_n(sys_rst_n),
.rx(rx),
.tx(tx)
);

endmodule
