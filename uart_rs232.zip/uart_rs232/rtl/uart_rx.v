module uart_rx
#(parameter	BAUD		=	'd115200,//'d115200,
  parameter	CLK_FREQ	=	'd50_000_000//'d50_000_000

)
(
input 				sys_clk,
input 				sys_rst_n,
input 				rx,
output	reg[7:0]	rx_data,		   
output	reg		rx_done
);
reg				rx_reg1;
reg				rx_reg2;
reg				rx_reg3;
reg				start_flag;
reg				work_en;
reg		[15:0]baud_cnt;
reg				bit_flag;
reg		[3:0]	bit_cnt;
reg		[7:0]	rx_data_temp;
reg				rx_done_temp;

always@(posedge sys_clk or negedge sys_rst_n)//打两拍，第三拍为了检测下降沿
begin
	if(sys_rst_n==0)
		begin
			rx_reg1<=1;
			rx_reg2<=1;
			rx_reg3<=1;
		end
	else
		begin
			rx_reg1<=rx;
			rx_reg2<=rx_reg1;
			rx_reg3<=rx_reg2;
		end
end
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
		start_flag<=0;
	else if((rx_reg3==1)	&&	(rx_reg2==0)	&&	(work_en==0))
		start_flag<=1;
		else
		start_flag<=0;
///////////////////////////////////////////////////////////////////////起始位防抖+对齐
/*reg [3:0] start_filter;
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
		start_filter <= 0;
	else if((rx_reg3==1) && (rx_reg2==0))  // 检测下降沿
		start_filter <= 1;                // 开始计数
	else if(start_filter == 15)
		start_filter <= 0;
	else	if(start_filter != 0)
		start_filter <= start_filter + 1;  // 计数延时
	else
		start_filter <= start_filter;
// 延时16个时钟再启动 = 自动对齐到起始位中点！
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
		start_flag<=0;
	else if(start_filter == 16)           // 等稳定再启动
		start_flag<=1;
	else
		start_flag<=0;*/
////////////////////////////////////////////////////////////////////		
always@(posedge sys_clk or negedge sys_rst_n)
begin
	if(sys_rst_n==0)
		work_en<=0;
	else
		if(start_flag==1)
			work_en<=1;
	else	if((bit_cnt==4'd8)&&(bit_flag==1))
			work_en<=0;
	else
			work_en<=work_en;
end


always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			baud_cnt<=0;
	else if((baud_cnt==CLK_FREQ/BAUD-1)||(work_en==0))
			baud_cnt<=0;
	else
			baud_cnt<=baud_cnt+1'b1;

always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			bit_flag<=0;
	else if	(baud_cnt==(CLK_FREQ/BAUD)/2)
			bit_flag<=1;
	else	
			bit_flag<=0;
			
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			bit_cnt<=0;
	else if	((bit_flag==1)&&(bit_cnt==4'd8))
			bit_cnt<=0;
	else if	(bit_flag==1)
			bit_cnt<=bit_cnt+1;
	else
			bit_cnt<=bit_cnt;
always@(posedge sys_clk or negedge sys_rst_n)//拼接
	if(sys_rst_n==0)
			rx_data_temp<=0;
	else if	((bit_flag==1)&&(bit_cnt!=0)&&(work_en==1))
			rx_data_temp[bit_cnt-1]<=	rx_reg3;
	else	if(start_flag==1)
			rx_data_temp<=0;
	else
			rx_data_temp<=rx_data_temp;
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			rx_done_temp<=0;
	else if((bit_flag==1)&&(bit_cnt==4'd8))
			rx_done_temp<=1'b1;
	else
			rx_done_temp<=1'b0;
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			rx_done<=0;
	else
			rx_done<=rx_done_temp;
	
always@(posedge sys_clk or negedge sys_rst_n)
	if(sys_rst_n==0)
			rx_data<=1'b0;
	else if(rx_done_temp==1'b1)
			rx_data<=rx_data_temp;
	else
			rx_data<=rx_data;
endmodule