module uart_data_loop
(
input					sys_clk,
input					sys_rst_n,
input			[7:0]	rx_data,	
input					rx_done,
input	 				tx_busy,
output	reg		tx_start,
output	reg[7:0]	tx_data	
);

reg					tx_req;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_req<=0;
	 else if(rx_done==1)
		tx_req<=1;
	 else if(tx_busy==1)
		tx_req<=0;
	 else
		tx_req<=tx_req;
end		
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_start<=0;
	 else if(tx_req==1)
		tx_start<=1;
	 else if(tx_busy==1)
		tx_start<=0;
end		
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_data<=0;
	 else if(rx_done==1)
		tx_data<=rx_data;
end
endmodule

/*reg [13:0] cnt;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_req<=0;
		else if(cnt=='d5999)
		tx_req<=1;
	 else if(tx_busy==1)
		tx_req<=0;
	 else
		tx_req<=tx_req;
end

always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_start<=0;
	 else if(tx_req==1)
		tx_start<=1;
	 else if(tx_busy==1)
		tx_start<=0;
end		
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		tx_data<=0;
	 else 
		tx_data<=8'b0101_0101;
end
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
		cnt<=0;
	else if(cnt=='d5999)
		cnt<=0;
	else
		cnt<=cnt+1;
end*/
