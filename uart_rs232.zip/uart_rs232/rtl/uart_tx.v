module uart_tx
#(
	parameter	BAUD		=	'd115200,//'d115200,
	parameter	CLK_FREQ	=	'd50_000_000,//'d50_000_000
	parameter	STOP_BIT_NUM	=	1
)
(
input					sys_clk,
input					sys_rst_n,
input					tx_start,
input			[7:0]	tx_data,	

output	reg		tx_busy,
output	reg		tx
);
localparam		BAUD_CNT_MAX = CLK_FREQ/BAUD	-1	;
parameter		IDLE				=	2'b00;
parameter		START_BIT		=	2'b01;
parameter		DATA_BIT			=	2'b10;
parameter		STOP_BIT			=	2'b11;

reg		[1:0]	state;
reg		[15:0]baud_cnt;
reg		[3:0]	bit_cnt;
reg		[7:0]	tx_data_reg;


//------------------------------
// 第1段：状态转移（时序逻辑）
//------------------------------
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
        state <= IDLE;
	 else begin
	 case(state)
        IDLE: begin
            if(tx_start)
                state <= START_BIT;
        end
        
        START_BIT: begin
            if(baud_cnt == BAUD_CNT_MAX )
                state <= DATA_BIT;
        end
        
        DATA_BIT: begin
            // 发完 8 位数据
            if(bit_cnt == 4'd8) 
                state <= STOP_BIT;
        end
        
        STOP_BIT: begin
            if(baud_cnt == BAUD_CNT_MAX )
                state <= IDLE;
        end
    endcase
	 end
end

//------------------------------
// 第2段：输出控制（时序逻辑）
//------------------------------
always @(posedge sys_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        tx          <= 1'b1;     // UART 空闲高电平
        tx_busy     <= 1'b0;
        baud_cnt    <= 16'd0;
        bit_cnt     <= 4'd0;
        tx_data_reg <=	8'd0;                         
    end
    else begin
        case(state)
            IDLE: begin
                tx          <= 1'b1;
                tx_busy     <= 1'b0;
                baud_cnt    <= 16'd0;
                bit_cnt     <= 4'd0;
                if(tx_start) begin
                    tx_data_reg <= tx_data;  // 锁存待发送数据
                    tx_busy     <= 1'b1;     // 标记忙
                end
            end
            
            START_BIT: begin
                tx <= 1'b0;  						// 起始位：0
                if(baud_cnt == BAUD_CNT_MAX )
                    baud_cnt <= 16'd0;
                else
                    baud_cnt <= baud_cnt + 1'b1;
            end
            
            DATA_BIT: begin
					 if(bit_cnt==8)	 
						  tx	<=1'b1;
					 else
						  tx <= tx_data_reg[bit_cnt];  // 依次发送 LSB 优先
                if(baud_cnt ==BAUD_CNT_MAX ) begin
                    baud_cnt <= 16'd0;
                    bit_cnt  <= bit_cnt + 1'b1;
                end
                else begin
                    baud_cnt <= baud_cnt + 1'b1;
                end
            end
            
            STOP_BIT: begin
                tx <= 1'b1;  // 停止位：1
                if(baud_cnt == BAUD_CNT_MAX )
                    baud_cnt <= 16'd0;
                else
                    baud_cnt <= baud_cnt + 1'b1;
            end
        endcase
    end
end

endmodule