module divisor_odd
#(parameter	N=3)
(
input			clkin,
output		clkout
);
reg[3:0]		cnt;
reg			clk_p;
reg			clk_n;

always@(posedge clkin)
	if(cnt<N-1)
		cnt<=cnt+1;
	else
		cnt<=0;
always@(posedge	clkin)
	if(cnt==N-1)
		clk_p<=~clk_p;
	else
		clk_p<=clk_p;
always@(negedge	clkin)
	if(cnt==(N-1)/2)
		clk_n<=~clk_n;
	else
		clk_n<=clk_n;
assign	clkout = clk_p  ^	clk_n;
endmodule