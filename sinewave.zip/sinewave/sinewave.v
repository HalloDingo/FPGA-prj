module sinewave(
input		clk,
//intput	[7:0]		addr,
output	[7:0]		dataout
);

reg		[7:0]		addr;
initial
addr=0;

always@(posedge clk)
begin
	if(addr<256)
		addr<=addr+1;
	else
		addr<=0;
end

sine_rom inst_sine_rom
(
	.address(addr),
	.clock(clk),
	.q(dataout)
);
endmodule
