`timescale 1ns/10ps
module readfile_tb();
//reg [7:0]	databus;
//reg [7:0]	sinewave	[255:0];
reg	clk;
wire[7:0]	dataout;

integer j;

initial
begin
	clk=0;
	//$readmemh("sinewave.txt",sinewave);
	j=$fopen("dataout.txt");
	
	//for(i=0;i<256;i=i+1)
	//	begin
	//		databus = sinewave[i];
			
	//		#10;
	//	end
	
	#2600	$fclose(j);
end

always #5 
begin	
		clk=~clk;
		
end

always #10 $fstrobe(j,"%h",dataout);
/*initial
begin
	
	j=$fopen("dataout.txt");

	$fmonitor(j,"%h",dataout);

	$fclose(j);
end
*/
sinewave sinewave_inst
(
.clk(clk),
.dataout(dataout)
);
endmodule
